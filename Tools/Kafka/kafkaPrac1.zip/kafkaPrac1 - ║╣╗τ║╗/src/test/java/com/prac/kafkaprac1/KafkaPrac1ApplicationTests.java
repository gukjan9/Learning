package com.prac.kafkaprac1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KafkaPrac1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
