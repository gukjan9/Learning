package com.prac.kafkaprac1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KafkaPrac1Application {

	public static void main(String[] args) {
		SpringApplication.run(KafkaPrac1Application.class, args);
	}

}
